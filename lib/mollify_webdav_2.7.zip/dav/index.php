<?php
	// NOTE! Modify these according to the location of the script
	$MOLLIFY_BACKEND_ROOT = "../";
	$BASE_URI = "/mollify/backend/dav/";
	
	$ENABLE_LOCKING = TRUE;
	$ENABLE_BROWSER = FALSE;
	$ENABLE_TEMPORARY_FILE_FILTER = TRUE;
	$BASIC_AUTH = FALSE;
	//$MAX_FILE_SIZE = "10M";
	
	require_once("mollify_dav.php");
?>